# JavaScript Practice: Variables

**Student Name:** Megha Khakare  
**Roll Number:** SCFU125101  
**Branch:** CSE  

## Files
- `index.html` — loads the external JavaScript file.
- `script.js` — solutions for all 10 questions.

## Run
1. Replace `YOUR COLLEGE NAME` and `YOUR CITY` in `script.js`.
2. Open `index.html` in Chrome or use VS Code Live Server.
3. Press `Ctrl + Shift + J` to open the browser Console.
4. Capture the real Console screenshots for Q1–Q10.

## Submission checklist
- Upload `index.html`, `script.js`, and `README.md` to the GitHub repository named `fsd1-js-variables`.
- Take Console screenshots for every question, including the expected errors in Q4 and Q5.
- Add the actual GitHub repository URL to the submission document.
- Attach the document and screenshots to the college assignment.
