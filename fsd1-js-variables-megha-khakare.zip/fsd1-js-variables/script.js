// JavaScript Practice: Variables
// Student: Megha Khakare | Branch: CSE | Roll No: SCFU125101
// Replace YOUR COLLEGE NAME and YOUR CITY with your actual details.

// Q1
console.log("Q1: Welcome Message");
console.log("Welcome to JavaScript");

// Q2
console.log("Q2: Student Details");
const studentName = "Megha Khakare";
const rollNumber = "SCFU125101";
const branch = "CSE";
const city = "YOUR CITY";
console.log("Name:", studentName);
console.log("Roll Number:", rollNumber);
console.log("Branch:", branch);
console.log("City:", city);

// Q3
console.log("Q3: Changing Marks");
let marks = 50;
console.log("Marks:", marks);
marks = 75;
console.log("Updated marks:", marks);

// Q4: const reassignment error (caught so the remaining questions run)
console.log("Q4: Const Reassignment Error");
const collegeName = "YOUR COLLEGE NAME";
console.log("College:", collegeName);
try {
  collegeName = "Another College";
} catch (error) {
  console.log("Expected error:", error.name + ": " + error.message);
}

// Q5
console.log("Q5: var and let");
var course = "Java";
var course = "JavaScript";
console.log("var after redeclaration:", course);

let subject = "HTML";
console.log("let before reassignment:", subject);
subject = "CSS";
console.log("let after reassignment:", subject);
try {
  eval('let demo = "First"; let demo = "Second";');
} catch (error) {
  console.log("Expected let redeclaration error:", error.name + ": " + error.message);
}

// Q6
console.log("Q6: Undefined and Assignment");
let x;
console.log("Initial x:", x);
x = "Hello";
console.log("Updated x:", x);

// Q7
console.log("Q7: Swap Values");
let a = "Mango";
let b = "Apple";
let temp = a;
a = b;
b = temp;
console.log("a =", a);
console.log("b =", b);

// Q8
console.log("Q8: Counter");
let count = 0;
console.log(count);
count = 1;
console.log(count);
count = 2;
console.log(count);
count = 3;
console.log(count);

// Q9
console.log("Q9: Corrected Code");
let price2 = 100; // Identifier cannot start with a number.
const correctedCity = "Pune"; // const must be initialized.
let name = "Riya";
name = "Asha"; // Reassignment, not redeclaration.
console.log("Price:", price2);
console.log("City:", correctedCity);
console.log("Name:", name);

// Q10
console.log("Q10: Student Card");
const cardName = "Megha Khakare";
let age = 21; // Change if your age is different.
const courseName = "Computer Science Engineering";
const college = "YOUR COLLEGE NAME";
console.log("Name:", cardName);
console.log("Age:", age);
console.log("Course:", courseName);
console.log("College:", college);
